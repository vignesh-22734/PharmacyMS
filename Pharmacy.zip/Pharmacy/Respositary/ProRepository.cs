﻿using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System;
using Pharmacy.Models;

public class ProRepository
{

    private SqlConnection con;
    //To Handle connection related activities    
    private void connection()
    {
        string constr = ConfigurationManager.ConnectionStrings["getconn"].ToString();
        con = new SqlConnection(constr);

    }
    //To Add Employee details    
    public bool AddProduct(Product obj)
    {

        connection();
        SqlCommand com = new SqlCommand("AddProduct", con);
        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@MedCode", obj.MedCode);
        com.Parameters.AddWithValue("@MedicineName", obj.MedicineName);
        com.Parameters.AddWithValue("@Photo", obj.Photo);
        com.Parameters.AddWithValue("@MedCategory", obj.MedCategory);
        com.Parameters.AddWithValue("@Manfacture", obj.Manfacture);
        com.Parameters.AddWithValue("@Exp", obj.Exp);
        com.Parameters.AddWithValue("@Price", obj.Price);

        con.Open();
        int i = com.ExecuteNonQuery();
        con.Close();
        if (i >= 1)
        {

            return true;

        }
        else
        {

            return false;
        }


    }
    //To view employee details with generic list     
    public List<Product> GetProduct()
    {
        connection();
        List<Product> ProList = new List<Product>();


        SqlCommand com = new SqlCommand("GetProduct", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataTable dt = new DataTable();

        con.Open();
        da.Fill(dt);
        con.Close();
        //Bind EmpModel generic list using dataRow     
        foreach (DataRow dr in dt.Rows)
        {

            ProList.Add(

                new Product
                {

                    Product_id = Convert.ToInt32(dr["Product_id"]),
                    MedCode = Convert.ToString(dr["MedCode"]),
                    MedicineName = Convert.ToString(dr["MedicineName"]),
                    MedCategory = Convert.ToInt32(dr["MedCategory"]),
                    Manfacture = Convert.ToString(dr["Manfacture"]),
                    Exp = Convert.ToString(dr["Exp"]),
                    Price = Convert.ToInt32(dr["Price"]),
                }
                );
        }

        return ProList;
    }
    //To Update Employee details    
    public bool UpdateProduct(Product obj)
    {

        connection();
        SqlCommand com = new SqlCommand("UpdateProduct", con);

        com.CommandType = CommandType.StoredProcedure;
        com.Parameters.AddWithValue("@Product_id", obj.Product_id);
        com.Parameters.AddWithValue("@MedCode", obj.MedCode);
        com.Parameters.AddWithValue("@MedicineName", obj.MedicineName);
        com.Parameters.AddWithValue("@Photo", obj.Photo);
        com.Parameters.AddWithValue("@MedCategory", obj.MedCategory);
        com.Parameters.AddWithValue("@Manfacture", obj.Manfacture);
        com.Parameters.AddWithValue("@Exp", obj.Exp);
        com.Parameters.AddWithValue("@Price", obj.Price);
        con.Open();
        int i = com.ExecuteNonQuery();
        con.Close();
        if (i >= 1)
        {

            return true;
        }
        else
        {
            return false;
        }
    }
    //To delete Employee details    
    public bool DeleteProduct(int ProductId)
    {

        connection();
        SqlCommand com = new SqlCommand("DeleteProduct", con);

        com.CommandType = CommandType.StoredProcedure;
        
        com.Parameters.AddWithValue("@Product_id", ProductId);

        con.Open();
        int i = com.ExecuteNonQuery();
        con.Close();
        if (i >= 1)
        {
            return true;
        }
        else
        {

            return false;
        }
    }
}