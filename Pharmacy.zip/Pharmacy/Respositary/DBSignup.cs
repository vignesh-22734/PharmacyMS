﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace Pharmacy.Repository
{
    public class DBSignup
    {
        public SqlConnection connect = new SqlConnection(ConfigurationManager.ConnectionStrings["getconn"].ConnectionString);

        public bool add(signup model)
        {
            
            SqlCommand cmd = new SqlCommand("sp_insertregistration", connect);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@action", "create");
            
            cmd.Parameters.AddWithValue("@firstname", model.firstname);
            cmd.Parameters.AddWithValue("@lastname", model.lastname);
            cmd.Parameters.AddWithValue("@dateofbirth", model.date);
            cmd.Parameters.AddWithValue("@gender", model.gender);
            cmd.Parameters.AddWithValue("@phone", model.phone);
            cmd.Parameters.AddWithValue("@email", model.email);


            cmd.Parameters.AddWithValue("@address", model.address);

            cmd.Parameters.AddWithValue("@state", model.state);

            cmd.Parameters.AddWithValue("@city", model.city);

            cmd.Parameters.AddWithValue("@username", model.username);
            cmd.Parameters.AddWithValue("@password", model.password);
            cmd.Parameters.AddWithValue("@status", 0);

            if (connect.State == ConnectionState.Closed)
                connect.Open();
            int i = cmd.ExecuteNonQuery();
            connect.Close();
            if (i >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public int IsValidLogin(signup user)
        {
            SqlCommand cmd = new SqlCommand("countLoginCredential", connect);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", user.username);
            cmd.Parameters.AddWithValue("@password", user.password);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable datatable = new DataTable();
            adapter.Fill(datatable);
            int j = 0;
            foreach (DataRow datarow in datatable.Rows)
            {
                j = Convert.ToInt32(datarow[0]);
            }
            return j;
        }
        public List<signup> SelectUserData()
        {
            List<signup> userlist = new List<signup>();
            SqlCommand cmd = new SqlCommand("GetDetails", connect);
            //cmd.Parameters.AddWithValue("@username", user.Username);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            adapter.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                userlist.Add(new signup
           
                {
                    id = Convert.ToInt32(dr[0]),
                    firstname = Convert.ToString(dr[1]),
                    lastname = Convert.ToString(dr[2]),
                    date = Convert.ToString(dr[3]),
                    gender = Convert.ToString(dr[4]),
                    phone = Convert.ToString(dr[5]),
                    email = Convert.ToString(dr[6]),
                    address = Convert.ToString(dr[7]),
                    state = Convert.ToString(dr[8]),
                    city = Convert.ToString(dr[9]),
                    username = Convert.ToString(dr[10]),
                    //password = Convert.ToString(dr[11]),
                    status = Convert.ToInt32(dr[12])

                });
                Console.WriteLine(userlist.Count);
            }
            return userlist;
        }
    }
}