﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using System;

public class signup
{
    public int id { get; set; }
    [Display(Name = "First name")]
    //[Required(ErrorMessage = "Enter the firstname")]
    public string firstname { get; set; }
    [Display(Name = "Last name")]
    //[Required(ErrorMessage = "Enter the lastname")]
    public string lastname { get; set; }

    [Display(Name = "Date of birth")]
    [DataType(DataType.Date)]
    [DisplayFormat(DataFormatString = "{0:MM//dd/yyy}", ApplyFormatInEditMode = true)]

    //[Required(ErrorMessage = "Enter the Date of birth")]


    public string date { get; set; }

    [Display(Name = "Gender")]
    [Required(ErrorMessage = "Enter the gender")]

    public string gender { get; set; }

    [Display(Name = "Phone number")]
    //[Required(ErrorMessage = "Enter the phone")]
    public string phone { get; set; }

    [Display(Name = "Email ID")]
    //[Required(ErrorMessage = "Enter the email")]
    public string email { get; set; }

    [Display(Name = "Address")]
    [DataType(DataType.MultilineText)]

    //[Required(ErrorMessage = "Enter th e address")]
    public string address { get; set; }

    [Display(Name = "State")]

    //[Required(ErrorMessage = "Enter the state")]
    public string state { get; set; }

    [Display(Name = "City")]
    //[Required(ErrorMessage = "Enter the city")]
    public string city { get; set; }
    [Display(Name = "Username")]

    //[Required(ErrorMessage = "Enter the user name")]
    public string username { get; set; }
    [Display(Name = "Password")]
    [DataType(DataType.Password)]


    //[Required(ErrorMessage = "Enter the password")]
    public string password { get; set; }
    [Display(Name = "Confirm password")]
    [DataType(DataType.Password)]
    //[Compare("password", ErrorMessage = "password mismatch")]
    public string confirmpassword { get; set; }

    [Display(Name = "Status")]

    public int status { get; set; }

}