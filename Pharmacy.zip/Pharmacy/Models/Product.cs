﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Pharmacy.Models
{
    public class Product
    {

        public int Product_id { get; set; }
        
        public string MedCode  { get; set; }
        public string MedicineName { get; set; }
        public byte[] Photo  { get; set; }
        public int MedCategory { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
       
        public string Manfacture { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
        public string Exp { get; set; }

        public int Price { get; set; }
       
    }
}