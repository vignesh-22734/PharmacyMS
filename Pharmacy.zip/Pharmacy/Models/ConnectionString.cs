﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pharmacy.Models
{
    public class ConnectionString
    {
        private static string constr = "Data Source=DESKTOP-S5PEAI0\\SQLEXPRESS;Initial Catalog=pharmacy;Integrated Security=True";

        public static string Constr
        {
            get => constr;
        }
    }
}