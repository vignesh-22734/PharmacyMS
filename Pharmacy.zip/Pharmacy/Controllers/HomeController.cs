﻿using Pharmacy.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Pharmacy.Controllers
{
    public class HomeController : Controller
    {
        private object databaseService;

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Aspire Pharmacy";

            return View();
        }

       
        public ActionResult Signup()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult ADD()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ADD(signup e)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    DBSignup dbobject = new DBSignup();

                    if (dbobject.add(e))
                    {

                        ViewBag.Message = "suceesfully";

                        return RedirectToAction("Getdetails");

                    }

                }


                return RedirectToAction("Getdetails");

            }
            catch
            {
                return View();
            }


        }

        public ActionResult Signin()
        {
            return View();

        }
        [HttpPost]
        public ActionResult Signin(signup userModel)
        {
            DBSignup databaseService = new DBSignup();
            int i = databaseService.IsValidLogin(userModel);
           
            if (i > 0)
            {
                var row = databaseService.SelectUserData().Find(model => model.username == userModel.username);
                ViewBag.addmessage = "<script>alert('Signin successful.')</script>";
                var username = row.username;
                Session["Username"] = username;
                if (row.status == 1)
                    return RedirectToAction("Index", "User");
                else
                    return RedirectToAction("Index","Admin");
            }
            else
            {
                ModelState.Clear();
                ViewBag.addmessage = "<script>alert('Incorrect username or password.')</script>";
                return View();
            }

        }
    }
}