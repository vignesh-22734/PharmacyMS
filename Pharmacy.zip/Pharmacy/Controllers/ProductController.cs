﻿using Pharmacy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Pharmacy.Controllers
{
    public class ProductController : Controller
    {

          
        public ActionResult GetProduct()
        {

            ProRepository ProRepo = new ProRepository();
            ModelState.Clear();
            return View(ProRepo.GetProduct());
        }
           
        public ActionResult AddProduct()
        {
            return View();
        }

          
        [HttpPost]
        public ActionResult AddProduct(Product Pro)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ProRepository ProRepo = new ProRepository();

                    if (ProRepo.AddProduct(Pro))
                    {
                        ViewBag.Message = " details added successfully";
                    }
                }

                return View();
            }
            catch
            {
                return View();
            }
        }

      
        public ActionResult EditProduct(int id)
        {
            ProRepository ProRepo = new ProRepository();



            return View(ProRepo.GetProduct().Find(Pro => Pro.Product_id == id));

        }

        
        [HttpPost]

        public ActionResult EditProduct(int id, Product obj)
        {
            try
            {
                ProRepository ProRepo = new ProRepository();

                ProRepo.UpdateProduct(obj);
                return RedirectToAction("GetProduct");
            }
            catch
            {
                return View();
            }
        }

      
        public ActionResult DeleteProduct(int id)
        {
            try
            {
                ProRepository ProRepo = new ProRepository();
                if (ProRepo.DeleteProduct(id))
                {
                    ViewBag.AlertMsg = " details deleted successfully";

                }
                return RedirectToAction("GetProduct");

            }
            catch
            {
                return View();
            }
        }
    }
}